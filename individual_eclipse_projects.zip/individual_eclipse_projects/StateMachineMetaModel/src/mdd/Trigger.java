/**
 */
package mdd;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Trigger</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see mdd.MddPackage#getTrigger()
 * @model
 * @generated
 */
public interface Trigger extends EObject {
} // Trigger
